# LogisticRegression
Logistic regression from scratch in Python

This example uses gradient descent to fit the model.
It also contains a Scikit Learn's way of doing logistic regression, so we can compare the two implementations.
